/* Nicol Heijtbrink, 10580611, main2.js */

window.onload = function() {
	
	var svgCountry = document.getElementsByTagName('title');
	console.log(svgCountry[1]);
	var countryContent = svgCountry.getElementById('France');
	console.log(countryContent);

	// changeColor("Norway", "#3498db");

	var data = document.getElementById("rawdata").value;
	var obj = JSON.parse(data);

	for (var i = 0; i < (obj["Points"].length - 1); i = i + 1){
		country = obj["Points"][i]["country"];
		population1 = (obj["Points"][i]["population"]);
		population = parseFloat(population1.split(',').join(''));
		console.log(population);
		if (population > 100000000) {
			console.log("heel veel");
			// #8e0152
		}
		else if (population > 50000000) {
			console.log("ook veel");
			// #c51b7d
		}
		else if (population > 10000000) {
			console.log("veel");
			// #de77ae
		}
		else if (population > 5000000) {
			console.log("medium");
			// #f1b6da
		}
		else if (population > 1000000) {
			console.log("best weing");
			// #fde0ef
		}
		else if (population > 500000) {
			console.log("redelijk weing");
			// #e6f5d0
		}
		else if (population > 100000) {
			console.log("weing");
			// #b8e186
		}
		else if (population > 50000) {
			console.log("heel weing");
			// #7fbc41
		}
		else if (population > 10000) {
			console.log("super weing");
			// #4d9221
		}
		else if (population < 10000) {
			console.log("tera weing");
			// #276419
		}
	}

}
function changeColor(id, color) {
	var svgCountry = document.getElementsByTagName('id');
	svgCountry.style.fill=color;
}
